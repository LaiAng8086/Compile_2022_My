package Frontend.Syntax.Storage;

public interface BlockItem {
}
