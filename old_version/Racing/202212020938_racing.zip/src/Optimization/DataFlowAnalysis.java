package Optimization;

import LLVMIR.Type.VoidType;
import LLVMIR.Value.Argument;
import LLVMIR.Value.BasicBlock;
import LLVMIR.Value.Instruction.*;
import LLVMIR.Value.Value;

import java.util.*;

public class DataFlowAnalysis {
    private BasicBlock toDealwith;

    public DataFlowAnalysis(BasicBlock input) {
        toDealwith = input;
    }

    public void analyzeDataFlow() {
        LinkedList<AbstractInstruction> ins = toDealwith.getInsList();
        ListIterator it = ins.listIterator(ins.size());
        int index = ins.size() - 1;
        while (it.hasPrevious()) {
            AbstractInstruction now = (AbstractInstruction) it.previous();
            now.setUseIndex(index);
            for (Value q : now.getOperands()) {
                q.updateMaxUseLine(index);
            }
            index--;
        }
    }

    //删除只定义，未使用的指令
    public void deleteDeadCode() {
        LinkedList<AbstractInstruction> ins = toDealwith.getInsList();
        LinkedList<AbstractInstruction> ret = new LinkedList<>();
        Iterator it = ins.iterator();
        while (it.hasNext()) {
            AbstractInstruction now = (AbstractInstruction) it.next();
            if (now.getMaxUseLine() > 0) {  //只定义不使用的会被删掉
                ret.add(now);
            } else if (now instanceof StoreInstruction || now instanceof RetInstruction
                    || now instanceof BrInstruction || now instanceof AllocaInstruction
                    || now instanceof CallInstruction) {
                ret.add(now);
            }   //call也是不能删的，尽管返回值可能没用，但是里面可能对全局或数组有副作用
        }
        toDealwith.setInsList(ret);
    }

    //复制传播与常量传播，旨在在同一个基本块中，对同一个地址，中间代码仅load和store一次

    private HashMap<String, Value> addrToVirReg;
    private HashMap<String, String> replacement;
    private HashMap<String, Value> nameToVal;
    private HashMap<String, StoreInstruction> lastStore;

    private Value getReplaced(Value t) {
        String now = t.getName();
        while (replacement.containsKey(now)) {
            now = replacement.get(now);
        }
        return nameToVal.getOrDefault(now, t);
    }

    public void copyForward() {
        LinkedList<AbstractInstruction> ins = toDealwith.getInsList();
        LinkedList<AbstractInstruction> ret = new LinkedList<>();
        addrToVirReg = new HashMap<>();
        replacement = new HashMap<>();
        nameToVal = new HashMap<>();
        lastStore = new HashMap<>();
        Iterator it = ins.iterator();
        int index = 0;
        while (it.hasNext()) {
            AbstractInstruction now = (AbstractInstruction) it.next();
            //更新替换
            ArrayList<Value> oldOps = now.getOperands();
            ArrayList<Value> newOps = new ArrayList<>();
            for (Value q : oldOps) {
                newOps.add(getReplaced(q));
            }
            now.setOperandsAll(newOps);
            //更新替换结束
            if (now instanceof StoreInstruction) {
                StoreInstruction ss = (StoreInstruction) now;
                //形参必须保存，因为第一个块是立刻执行的
                lastStore.put(ss.getOp2().getName(), ss);    //保存每个地址的最后一次存储
                //更新每个地址的Value内容
                addrToVirReg.put(ss.getOp2().getName(), ss.getOp1());
                if (ss.getOp1() instanceof Argument) {
                    nameToVal.put(ss.getOp1().getName(), ss.getOp1());  //形参在基本块外，这里可能接触不到
                }
            } else if (now instanceof LoadInstruction) {
                if (addrToVirReg.containsKey(now.getOp1().getName()))    //不用加载，直接替换
                {
                    Value temp = addrToVirReg.get(now.getOp1().getName());
                    replacement.put(now.getName(), temp.getName());
                } else {
                    ret.add(now);
                    addrToVirReg.put(now.getOp1().getName(), now);
                    nameToVal.put(now.getName(), now);
                }
            } else {
                ret.add(now);
                if (now.getName() != null && !(now.getName().equals("%l") || now.getName().equals(""))) {
                    nameToVal.put(now.getName(), now);
                }
            }
            index++;
        }
        int lastIndex = ret.size() - 1;
        //插入跳转或返回之前
        for (Map.Entry<String, StoreInstruction> qwq : lastStore.entrySet()) {
            ret.add(lastIndex, qwq.getValue());
            lastIndex++;
        }
        toDealwith.setInsList(ret);
    }

    public void clearPreviousAnalysis() {
        LinkedList<AbstractInstruction> ins = toDealwith.getInsList();
        Iterator it = ins.iterator();
        while (it.hasNext()) {
            AbstractInstruction now = (AbstractInstruction) it.next();
            now.maxLineClear();
            for (Value t : now.getOperands()) {
                t.maxLineClear();
            }
        }
    }
}
