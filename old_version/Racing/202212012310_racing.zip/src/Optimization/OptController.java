package Optimization;

import Backend.MIPSProgram;
import LLVMIR.Module;
import LLVMIR.Value.BasicBlock;
import LLVMIR.Value.Constant.Function;

import java.util.ArrayList;

public class OptController {
    public static void middlePass() {
        ArrayList<Function> functions = Module.getInstance().getFunctions();
        for (Function now : functions) {
            for (BasicBlock bb : now.getBblocks()) {
                BlockCommonExpMerge qwq = new BlockCommonExpMerge(bb);
                qwq.mergeCommon();
                DataFlowAnalysis dana = new DataFlowAnalysis(bb);
                dana.analyzeDataFlow();
                dana.deleteDeadCode();
                dana.analyzeDataFlow();
            }
        }

    }

    public static void targetPass(MIPSProgram mips) {
        MulOpt.replaceMul2(mips);
    }
}
