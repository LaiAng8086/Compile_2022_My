package Frontend.Syntax.Parser;

public interface CommonParser {
    void Analyzer();
}
