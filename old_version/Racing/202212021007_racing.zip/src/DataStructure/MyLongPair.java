package DataStructure;

public class MyLongPair {
    long key, value;

    public MyLongPair(long src1, long src2) {
        key = src1;
        value = src2;
    }

    public long getKey() {
        return key;
    }

    public long getValue() {
        return value;
    }
}
