package Optimization;

import LLVMIR.Value.BasicBlock;
import LLVMIR.Value.Instruction.AbstractInstruction;
import LLVMIR.Value.Value;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.ListIterator;

public class DataFlowAnalysis {
    private BasicBlock toDealwith;

    public DataFlowAnalysis(BasicBlock input) {
        toDealwith = input;
    }

    public void analyzeDataFlow() {
        LinkedList<AbstractInstruction> ins = toDealwith.getInsList();
        ListIterator it = ins.listIterator(ins.size());
        int index = ins.size() - 1;
        while (it.hasPrevious()) {
            AbstractInstruction now = (AbstractInstruction) it.previous();
            now.setUseIndex(index);
            for (Value q : now.getOperands()) {
                q.updateMaxUseLine(index);
            }
            index--;
        }
    }
}
