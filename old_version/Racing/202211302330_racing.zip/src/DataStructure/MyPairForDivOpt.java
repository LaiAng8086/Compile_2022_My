package DataStructure;

import java.math.BigInteger;

public class MyPairForDivOpt {
    BigInteger a;
    int b;

    public MyPairForDivOpt(BigInteger x, int y) {
        a = x;
        b = y;
    }

    public BigInteger getA() {
        return a;
    }

    public int getB() {
        return b;
    }
}
