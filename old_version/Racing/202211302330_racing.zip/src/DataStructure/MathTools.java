package DataStructure;

public class MathTools {
    public static long getUnsignedInt(int input) {
        return input & 0xFFFFFFFFL;
    }
}
