package LLVMIR.Type;

public abstract class AbstractType {
    public abstract int getSize();

}
