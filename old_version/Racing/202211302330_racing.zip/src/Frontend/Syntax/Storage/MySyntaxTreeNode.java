package Frontend.Syntax.Storage;

import java.io.IOException;

public interface MySyntaxTreeNode {
    void output() throws IOException;
}
