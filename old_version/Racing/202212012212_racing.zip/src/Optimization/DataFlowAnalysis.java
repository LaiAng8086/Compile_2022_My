package Optimization;

import LLVMIR.Type.VoidType;
import LLVMIR.Value.BasicBlock;
import LLVMIR.Value.Instruction.*;
import LLVMIR.Value.Value;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.ListIterator;

public class DataFlowAnalysis {
    private BasicBlock toDealwith;

    public DataFlowAnalysis(BasicBlock input) {
        toDealwith = input;
    }

    public void analyzeDataFlow() {
        LinkedList<AbstractInstruction> ins = toDealwith.getInsList();
        ListIterator it = ins.listIterator(ins.size());
        int index = ins.size() - 1;
        while (it.hasPrevious()) {
            AbstractInstruction now = (AbstractInstruction) it.previous();
            now.setUseIndex(index);
            for (Value q : now.getOperands()) {
                q.updateMaxUseLine(index);
            }
            index--;
        }
    }

    //删除只定义，未使用的指令
    public void deleteDeadCode() {
        LinkedList<AbstractInstruction> ins = toDealwith.getInsList();
        LinkedList<AbstractInstruction> ret = new LinkedList<>();
        Iterator it = ins.iterator();
        while (it.hasNext()) {
            AbstractInstruction now = (AbstractInstruction) it.next();
            if (now.getMaxUseLine() > 0) {  //只定义不使用的会被删掉
                now.maxLineClear(); //为下一轮重新数据流分析做准备
                ret.add(now);
            } else if (now instanceof StoreInstruction || now instanceof RetInstruction
                    || now instanceof BrInstruction) {
                now.maxLineClear();
                ret.add(now);
            } else if (now instanceof CallInstruction) {
                if (now.getType() instanceof VoidType) {
                    now.maxLineClear();
                    ret.add(now);
                }
            }
        }
        toDealwith.setInsList(ret);
    }
}
